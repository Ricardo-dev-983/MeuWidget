package com.photowidgets;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.net.Uri;

import java.io.InputStream;

/**
 * Utilitário para operações de bitmap eficientes em memória.
 */
public class BitmapUtils {

    private static final int MAX_DIMENSION = 512;

    /**
     * Carrega um bitmap da URI com downsampling para economizar RAM.
     */
    public static Bitmap loadScaledBitmap(Context context, Uri uri) {
        try {
            // Passo 1: ler apenas dimensões
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            InputStream in = context.getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, options);
            if (in != null) in.close();

            // Passo 2: calcular inSampleSize
            options.inSampleSize = calculateInSampleSize(options, MAX_DIMENSION, MAX_DIMENSION);
            options.inJustDecodeBounds = false;
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;

            // Passo 3: decodificar com sample size
            in = context.getContentResolver().openInputStream(uri);
            Bitmap bmp = BitmapFactory.decodeStream(in, null, options);
            if (in != null) in.close();
            return bmp;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static int calculateInSampleSize(BitmapFactory.Options options, int reqW, int reqH) {
        int height = options.outHeight;
        int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqH || width > reqW) {
            int halfHeight = height / 2;
            int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqH && (halfWidth / inSampleSize) >= reqW) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    /**
     * Aplica o formato (retângulo, círculo, quadrado arredondado) ao bitmap.
     */
    public static Bitmap applyShape(Bitmap source, String shape) {
        if (source == null) return null;

        switch (shape) {
            case "CIRCLE":
                return applyCircle(source);
            case "ROUNDED":
                return applyRounded(source, source.getWidth() * 0.15f);
            default: // RECTANGLE
                return source;
        }
    }

    /**
     * Center-crop para quadrado e aplica máscara circular.
     */
    private static Bitmap applyCircle(Bitmap source) {
        int size = Math.min(source.getWidth(), source.getHeight());
        Bitmap cropped = centerCrop(source, size, size);

        Bitmap output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(cropped, 0, 0, paint);
        return output;
    }

    /**
     * Center-crop para quadrado e aplica cantos arredondados.
     */
    private static Bitmap applyRounded(Bitmap source, float radius) {
        int size = Math.min(source.getWidth(), source.getHeight());
        Bitmap cropped = centerCrop(source, size, size);

        Bitmap output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        Path path = new Path();
        path.addRoundRect(new RectF(0, 0, size, size), radius, radius, Path.Direction.CW);
        canvas.drawPath(path, paint);

        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(cropped, 0, 0, paint);
        return output;
    }

    public static Bitmap centerCrop(Bitmap source, int targetW, int targetH) {
        float scaleX = (float) targetW / source.getWidth();
        float scaleY = (float) targetH / source.getHeight();
        float scale = Math.max(scaleX, scaleY);

        int scaledW = (int) (source.getWidth() * scale);
        int scaledH = (int) (source.getHeight() * scale);

        Bitmap scaled = Bitmap.createScaledBitmap(source, scaledW, scaledH, true);
        int startX = (scaledW - targetW) / 2;
        int startY = (scaledH - targetH) / 2;
        return Bitmap.createBitmap(scaled, startX, startY, targetW, targetH);
    }
}
