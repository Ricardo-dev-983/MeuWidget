package com.photowidgets;

import android.Manifest;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

/**
 * Tela de configuração do widget.
 * Permite selecionar foto e escolher formato.
 */
public class WidgetConfigActivity extends Activity {

    private static final int REQUEST_PICK_IMAGE  = 1001;
    private static final int REQUEST_PERMISSION  = 1002;

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;

    // Views
    private ImageView imgPreview;
    private LinearLayout layoutPlaceholder;
    private LinearLayout layoutPermissionWarning;
    private Button btnSave;
    private Button btnSelectPhoto;
    private Button btnGrantPermission;

    // Shape containers
    private LinearLayout shapeRectangle;
    private LinearLayout shapeCircle;
    private LinearLayout shapeRounded;

    // State
    private Uri selectedUri = null;
    private String selectedShape = "RECTANGLE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_widget_config);

        // Resultado padrão CANCELADO (caso o usuário saia sem configurar)
        setResult(RESULT_CANCELED);

        // Recuperar o widget ID do intent
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            appWidgetId = extras.getInt(
                AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID
            );
        }

        initViews();
        loadExistingConfig();
        setupListeners();
        checkPermission();
    }

    private void initViews() {
        imgPreview            = findViewById(R.id.imgPreview);
        layoutPlaceholder     = findViewById(R.id.layoutPlaceholder);
        layoutPermissionWarning = findViewById(R.id.layoutPermissionWarning);
        btnSave               = findViewById(R.id.btnSave);
        btnSelectPhoto        = findViewById(R.id.btnSelectPhoto);
        btnGrantPermission    = findViewById(R.id.btnGrantPermission);
        shapeRectangle        = findViewById(R.id.shapeRectangle);
        shapeCircle           = findViewById(R.id.shapeCircle);
        shapeRounded          = findViewById(R.id.shapeRounded);
    }

    private void loadExistingConfig() {
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) return;

        String savedUri = WidgetPrefs.getPhotoUri(this, appWidgetId);
        String savedShape = WidgetPrefs.getShape(this, appWidgetId);

        if (!savedUri.isEmpty()) {
            selectedUri = Uri.parse(savedUri);
            selectedShape = savedShape;
            showPreview(selectedUri);
            selectShape(savedShape);
            enableSaveButton();
        }
    }

    private void setupListeners() {
        btnSelectPhoto.setOnClickListener(v -> pickPhoto());

        btnGrantPermission.setOnClickListener(v -> requestStoragePermission());

        btnSave.setOnClickListener(v -> saveAndFinish());

        shapeRectangle.setOnClickListener(v -> selectShape("RECTANGLE"));
        shapeCircle.setOnClickListener(v -> selectShape("CIRCLE"));
        shapeRounded.setOnClickListener(v -> selectShape("ROUNDED"));

        // Tocar no preview também abre a galeria
        findViewById(R.id.framePreview).setOnClickListener(v -> pickPhoto());
    }

    // ─── Permissão ────────────────────────────────────────────────────────────

    private void checkPermission() {
        if (!hasStoragePermission()) {
            layoutPermissionWarning.setVisibility(View.VISIBLE);
        }
    }

    private boolean hasStoragePermission() {
        String permission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
            ? Manifest.permission.READ_MEDIA_IMAGES
            : Manifest.permission.READ_EXTERNAL_STORAGE;
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestStoragePermission() {
        String permission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
            ? Manifest.permission.READ_MEDIA_IMAGES
            : Manifest.permission.READ_EXTERNAL_STORAGE;
        requestPermissions(new String[]{permission}, REQUEST_PERMISSION);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        if (requestCode == REQUEST_PERMISSION) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                layoutPermissionWarning.setVisibility(View.GONE);
                pickPhoto();
            } else {
                Toast.makeText(this, "Permissão negada. Não é possível acessar fotos.", Toast.LENGTH_LONG).show();
            }
        }
    }

    // ─── Seleção de foto ──────────────────────────────────────────────────────

    private void pickPhoto() {
        if (!hasStoragePermission()) {
            requestStoragePermission();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                // Persistir permissão de acesso à URI
                try {
                    getContentResolver().takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );
                } catch (Exception ignored) {}

                selectedUri = uri;
                showPreview(uri);
                enableSaveButton();
            }
        }
    }

    // ─── Preview ──────────────────────────────────────────────────────────────

    private void showPreview(final Uri uri) {
        new AsyncTask<Void, Void, Bitmap>() {
            @Override
            protected Bitmap doInBackground(Void... v) {
                Bitmap raw = BitmapUtils.loadScaledBitmap(WidgetConfigActivity.this, uri);
                return BitmapUtils.applyShape(raw, selectedShape);
            }
            @Override
            protected void onPostExecute(Bitmap bmp) {
                if (bmp != null) {
                    imgPreview.setImageBitmap(bmp);
                    imgPreview.setVisibility(View.VISIBLE);
                    layoutPlaceholder.setVisibility(View.GONE);
                    // Aplicar clip shape no container do preview
                    updatePreviewClip();
                }
            }
        }.execute();
    }

    private void updatePreviewClip() {
        FrameLayout frame = findViewById(R.id.framePreview);
        switch (selectedShape) {
            case "CIRCLE":
                frame.setBackground(getDrawable(R.drawable.shape_circle_preview));
                break;
            case "ROUNDED":
                frame.setBackground(getDrawable(R.drawable.shape_rounded_preview));
                break;
            default:
                frame.setBackground(getDrawable(R.drawable.bg_preview));
        }
    }

    // ─── Seleção de shape ─────────────────────────────────────────────────────

    private void selectShape(String shape) {
        selectedShape = shape;

        // Reset visual de todos
        shapeRectangle.setBackground(getDrawable(R.drawable.bg_shape_unselected));
        shapeCircle.setBackground(getDrawable(R.drawable.bg_shape_unselected));
        shapeRounded.setBackground(getDrawable(R.drawable.bg_shape_unselected));

        setTextColor(shapeRectangle, "#8888AA");
        setTextColor(shapeCircle, "#8888AA");
        setTextColor(shapeRounded, "#8888AA");

        // Destacar o selecionado
        LinearLayout selected;
        switch (shape) {
            case "CIRCLE":   selected = shapeCircle;    break;
            case "ROUNDED":  selected = shapeRounded;   break;
            default:         selected = shapeRectangle; break;
        }
        selected.setBackground(getDrawable(R.drawable.bg_shape_selected));
        setTextColor(selected, "#FFFFFF");

        // Re-renderizar preview com novo shape
        if (selectedUri != null) showPreview(selectedUri);
    }

    private void setTextColor(LinearLayout layout, String hexColor) {
        if (layout.getChildCount() >= 2) {
            android.widget.TextView tv = (android.widget.TextView) layout.getChildAt(1);
            tv.setTextColor(android.graphics.Color.parseColor(hexColor));
        }
    }

    // ─── Salvar ───────────────────────────────────────────────────────────────

    private void enableSaveButton() {
        btnSave.setEnabled(true);
        btnSave.setBackground(getDrawable(R.drawable.bg_button_enabled));
    }

    private void saveAndFinish() {
        if (selectedUri == null) return;
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) return;

        // Salvar no SharedPreferences
        WidgetPrefs.saveAll(this, appWidgetId, selectedUri.toString(), selectedShape);

        // Atualizar o widget
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        PhotoWidgetProvider.updateWidget(this, manager, appWidgetId);

        // Retornar OK para o launcher adicionar o widget
        Intent result = new Intent();
        result.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        setResult(RESULT_OK, result);
        finish();
    }
}
