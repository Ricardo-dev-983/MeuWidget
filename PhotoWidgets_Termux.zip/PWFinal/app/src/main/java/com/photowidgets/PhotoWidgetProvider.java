package com.photowidgets;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.widget.RemoteViews;

/**
 * AppWidgetProvider que gerencia o ciclo de vida do widget.
 * Carrega a foto salva e renderiza no widget da tela inicial.
 */
public class PhotoWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] widgetIds) {
        for (int widgetId : widgetIds) {
            updateWidget(context, manager, widgetId);
        }
    }

    @Override
    public void onDeleted(Context context, int[] widgetIds) {
        for (int id : widgetIds) {
            WidgetPrefs.deleteWidget(context, id);
        }
    }

    /**
     * Atualiza um widget específico. Carrega a imagem em background.
     */
    public static void updateWidget(Context context, AppWidgetManager manager, int widgetId) {
        new LoadBitmapTask(context, manager, widgetId).execute();
    }

    // ─── AsyncTask para carregar bitmap sem travar a UI ───────────────────────

    private static class LoadBitmapTask extends AsyncTask<Void, Void, Bitmap> {

        private final Context context;
        private final AppWidgetManager manager;
        private final int widgetId;
        private final String uriStr;
        private final String shape;

        LoadBitmapTask(Context context, AppWidgetManager manager, int widgetId) {
            this.context  = context.getApplicationContext();
            this.manager  = manager;
            this.widgetId = widgetId;
            this.uriStr   = WidgetPrefs.getPhotoUri(context, widgetId);
            this.shape    = WidgetPrefs.getShape(context, widgetId);
        }

        @Override
        protected Bitmap doInBackground(Void... v) {
            if (uriStr == null || uriStr.isEmpty()) return null;
            try {
                Uri uri = Uri.parse(uriStr);
                Bitmap raw = BitmapUtils.loadScaledBitmap(context, uri);
                return BitmapUtils.applyShape(raw, shape);
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);

            // Intent para abrir a tela de configuração ao tocar no widget
            Intent configIntent = new Intent(context, WidgetConfigActivity.class);
            configIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
            configIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent pi = PendingIntent.getActivity(
                context, widgetId, configIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            views.setOnClickPendingIntent(R.id.widgetImage, pi);
            views.setOnClickPendingIntent(R.id.widgetEmpty, pi);

            if (bitmap != null) {
                views.setImageViewBitmap(R.id.widgetImage, bitmap);
                views.setViewVisibility(R.id.widgetImage, android.view.View.VISIBLE);
                views.setViewVisibility(R.id.widgetEmpty, android.view.View.GONE);
            } else {
                views.setViewVisibility(R.id.widgetImage, android.view.View.GONE);
                views.setViewVisibility(R.id.widgetEmpty, android.view.View.VISIBLE);
            }

            manager.updateAppWidget(widgetId, views);
        }
    }
}
