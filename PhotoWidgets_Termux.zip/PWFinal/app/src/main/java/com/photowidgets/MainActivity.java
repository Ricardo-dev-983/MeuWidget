package com.photowidgets;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

/**
 * Tela principal do app — mostra instruções de como adicionar o widget.
 */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupSteps();

        Button btnOpenConfig = findViewById(R.id.btnOpenConfig);
        btnOpenConfig.setOnClickListener(v -> {
            // Abre a tela de configuração diretamente do app
            // (sem widget ID - apenas para visualização)
            Intent intent = new Intent(this, WidgetConfigActivity.class);
            startActivity(intent);
        });
    }

    private void setupSteps() {
        setStep(R.id.step1, "1", getString(R.string.step1));
        setStep(R.id.step2, "2", getString(R.string.step2));
        setStep(R.id.step3, "3", getString(R.string.step3));
        setStep(R.id.step4, "4", getString(R.string.step4));
    }

    private void setStep(int layoutId, String number, String text) {
        android.view.View stepView = findViewById(layoutId);
        if (stepView == null) return;
        TextView tvNumber = stepView.findViewById(R.id.tvStepNumber);
        TextView tvText   = stepView.findViewById(R.id.tvStepText);
        if (tvNumber != null) tvNumber.setText(number);
        if (tvText   != null) tvText.setText(text);
    }
}
