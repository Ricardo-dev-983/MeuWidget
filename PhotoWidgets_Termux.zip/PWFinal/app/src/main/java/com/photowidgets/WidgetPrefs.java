package com.photowidgets;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Gerencia a persistência de dados do widget usando SharedPreferences.
 * Cada widget é identificado pelo seu appWidgetId.
 * Os dados sobrevivem a reinicializações do celular.
 */
public class WidgetPrefs {

    private static final String PREF_FILE = "photo_widget_prefs";
    private static final String KEY_URI_PREFIX   = "uri_";
    private static final String KEY_SHAPE_PREFIX = "shape_";

    public static void savePhotoUri(Context ctx, int widgetId, String uri) {
        prefs(ctx).edit()
            .putString(KEY_URI_PREFIX + widgetId, uri)
            .apply();
    }

    public static String getPhotoUri(Context ctx, int widgetId) {
        return prefs(ctx).getString(KEY_URI_PREFIX + widgetId, "");
    }

    public static void saveShape(Context ctx, int widgetId, String shape) {
        prefs(ctx).edit()
            .putString(KEY_SHAPE_PREFIX + widgetId, shape)
            .apply();
    }

    public static String getShape(Context ctx, int widgetId) {
        return prefs(ctx).getString(KEY_SHAPE_PREFIX + widgetId, "RECTANGLE");
    }

    public static void saveAll(Context ctx, int widgetId, String uri, String shape) {
        prefs(ctx).edit()
            .putString(KEY_URI_PREFIX   + widgetId, uri)
            .putString(KEY_SHAPE_PREFIX + widgetId, shape)
            .apply();
    }

    public static void deleteWidget(Context ctx, int widgetId) {
        prefs(ctx).edit()
            .remove(KEY_URI_PREFIX   + widgetId)
            .remove(KEY_SHAPE_PREFIX + widgetId)
            .apply();
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE);
    }
}
